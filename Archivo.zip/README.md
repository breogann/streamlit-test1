# Tasador


## Instrucciones
conda create -y -n streamlit python=3.11
conda activate streamlit

touch app.py
pip install streamlit
streamlit run app.py

pip install pipreqs
pipreqs

pip install plotly
pip install folium
pip install streamlit_folium

pip install scikit-learn

# Modelo

- modelo?
- regresión
- VD, VI
- Coeficiente
- estimación
- predicción
- p_valor
- r2

1. Cargas los datos
2. Pre-procesamiento datos
3. Feature engineering
4. Train, test, split
5. Fit (entrenar) -> averiguar la ecuación de la recta ( y = mx + n)
6. y = model.precit(X)

