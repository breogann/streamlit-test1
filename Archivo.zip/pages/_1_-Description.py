import streamlit as st

st.title("Descripción de los datos")
st.markdown("""
Este conjunto de datos simula las características de pisos en una ciudad.

- **metros_cuadrados**: tamaño del piso en m2. int.
- **habitaciones**: número de habitaciones. int
- **baños**: número de baños. int.
- **garaje**: si tiene o no garaje (1) ó (0). int / boolean
- **antiguedad**
- precio 
            """)